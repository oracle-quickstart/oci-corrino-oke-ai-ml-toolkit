# OCI Networking module

> __Warning__: Moved to [oracle-quickstart/terraform-oci-networking](https://github.com/oracle-quickstart/terraform-oci-networking). Sub modules with specific OCI Networking resource also available. example: [Virtual Cloud Network](https://github.com/oracle-quickstart/terraform-oci-networking/tree/main/modules/vcn).
